# Panduan Setup POS Merchandise (Google Sheets + Apps Script)

Ikuti langkah ini secara berurutan. Total waktu kurang lebih 10-15 menit.

---

## LANGKAH 1 — Buat Google Sheet Baru

1. Buka [sheets.google.com](https://sheets.google.com)
2. Klik **Blank spreadsheet** untuk membuat sheet baru
3. Beri nama, misalnya: **POS Merchandise - Database**

---

## LANGKAH 2 — Buka Apps Script Editor

1. Di Google Sheet yang baru dibuat, klik menu **Extensions** (Ekstensi) di bagian atas
2. Pilih **Apps Script**
3. Akan terbuka tab baru dengan editor kode (judulnya "Untitled project")
4. Ganti nama project menjadi **POS Backend** (klik di pojok kiri atas, dekat logo)

---

## LANGKAH 3 — Paste Kode Backend

1. Di editor Apps Script, akan ada file `Code.gs` dengan kode default `function myFunction() {}`
2. **Hapus semua kode default** itu
3. **Copy seluruh isi file `AppsScript.gs`** yang sudah aku sediakan, lalu **paste** ke editor
4. Klik ikon **Save** (gambar disket) atau `Ctrl+S` / `Cmd+S`

---

## LANGKAH 4 — Jalankan Setup Awal

1. Di bagian atas editor, ada dropdown pilihan fungsi (biasanya tertulis "Select function")
2. Pilih fungsi **`setupSheets`**
3. Klik tombol **Run** (ikon segitiga/play)
4. **Akan muncul popup "Authorization required"** — ini normal, karena script perlu izin akses ke Sheet kamu sendiri:
   - Klik **Review permissions**
   - Pilih akun Google kamu
   - Akan ada peringatan "Google hasn't verified this app" — klik **Advanced** → **Go to POS Backend (unsafe)** (aman, ini script milikmu sendiri)
   - Klik **Allow**
5. Setelah selesai, akan muncul popup alert **"Setup selesai! Sheet sudah siap dipakai."**
6. Cek Google Sheet kamu — seharusnya sudah ada sheet baru: `Categories`, `Products`, `Bundles`, `Transactions`, `TransactionItems`

---

## LANGKAH 5 — Deploy sebagai Web App

1. Di editor Apps Script, klik tombol **Deploy** (pojok kanan atas) → **New deployment**
2. Klik ikon gear ⚙️ di sebelah "Select type" → pilih **Web app**
3. Isi konfigurasi:
   - **Description**: `POS Web App v1` (atau apa saja)
   - **Execute as**: **Me** (akun kamu)
   - **Who has access**: **Anyone** *(penting — supaya website bisa mengakses tanpa login Google)*
4. Klik **Deploy**
5. Akan muncul popup **"Authorize access"** lagi jika belum — ikuti seperti langkah 4
6. Setelah berhasil deploy, akan muncul **Web app URL** — bentuknya seperti:
   ```
   https://script.google.com/macros/s/AKfycb..................../exec
   ```
7. **COPY URL ini** — ini yang akan dimasukkan ke website POS

> ⚠️ **Simpan URL ini baik-baik.** Ini adalah "alamat" backend kamu. Tanpa URL ini, website POS tidak bisa terhubung ke data.

---

## LANGKAH 6 — Tes URL (opsional, untuk memastikan)

1. Buka tab browser baru
2. Paste URL Web App kamu, tambahkan `?action=getAllData` di belakangnya, contoh:
   ```
   https://script.google.com/macros/s/AKfycb..................../exec?action=getAllData
   ```
3. Tekan Enter
4. Jika berhasil, akan muncul teks JSON seperti:
   ```json
   {"products":[],"categories":[{"CategoryID":"CAT-001","CategoryName":"Pakaian"},...],"bundles":[]}
   ```
5. Jika muncul ini, **backend kamu sudah siap!**

---

## LANGKAH 7 — Masukkan URL ke Website POS

1. Buka website POS yang sudah aku buatkan
2. Saat pertama dibuka, akan ada kolom **"Masukkan URL Web App"**
3. Paste URL dari Langkah 5
4. Klik **Hubungkan**
5. Website akan langsung memuat data dari Google Sheet kamu

---

## CATATAN PENTING

### Kalau kamu mengubah/edit kode Apps Script di kemudian hari:
Setiap kali kamu **mengubah kode** di Apps Script, kamu harus **Deploy ulang**:
1. Klik **Deploy** → **Manage deployments**
2. Klik ikon pensil (edit) pada deployment yang aktif
3. Di bagian **Version**, pilih **New version**
4. Klik **Deploy**

URL Web App-nya **tetap sama**, tidak perlu update di website.

### Struktur Google Sheet yang terbentuk:
| Sheet | Isi |
|---|---|
| `Categories` | Daftar kategori produk |
| `Products` | Semua produk: nama, kategori, harga umum/karyawan, stok |
| `Bundles` | Paket bundling produk |
| `Transactions` | Header tiap transaksi (waktu, metode bayar, total) |
| `TransactionItems` | Rincian item per transaksi |

### Cara lihat laporan penjualan:
Ada 2 cara:
1. **Dari website POS** — tab "Laporan" akan menampilkan ringkasan otomatis (cash vs QRIS, barang terlaris, sisa stok)
2. **Generate Sheet Report manual** — di Google Sheet kamu, akan ada menu baru **"POS Tools"** di toolbar atas → klik **"Generate Sheet Report Sekarang"** untuk membuat sheet laporan baru yang rapi dan bisa di-print/export

### Kalau ada error "Stok tidak cukup" saat checkout:
Itu artinya stok produk di Sheet `Products` sudah habis atau kurang dari qty yang diminta. Cek dan tambah stok lewat menu **Manajemen Stok** di website, atau edit manual di Sheet.

---

Selesai! Sekarang website POS kamu sudah terhubung dan siap dipakai untuk transaksi sehari-hari.
